import React, { useState } from "react";

function App() {
  
  const [name, setName] = useState("");
  const [Age, setAge] = useState("");
  const [Gen, setGen] = useState("");
  const [TarCap, setTarCap] = useState("");
  const [InitCap, setInitCap] = useState("");
  const [NoDep, setNoDep] = useState("");
  const [YrFamInc, setYrFamInc] = useState("");
  const [MedBill, setMedBill] = useState("");
 

  function handleName(event) {
  
    setName(event.target.value);
  }
  function handleAge(event) {
  
    setAge(event.target.value);
  }
  function handleGen(event) {
  
    setGen(event.target.value);
  }
  function handleTarCap(event) {
  
    setTarCap(event.target.value);
  }
  function handleInitCap(event) {
  
    setInitCap(event.target.value);
  }
  function handleNoDep(event) {
  
    setNoDep(event.target.value);
  }
  function handleYrFamInc(event) {
  
    setYrFamInc(event.target.value);
  }
  function handleMedBill(event) {
  
    setMedBill(event.target.value);
  }
  
  

  

  return (
    <div className="container">

      <form >
        <input
          onChange={handleName}
          type="text"
          placeholder="Name"
          value={name}
        />
        <input
          onChange={handleAge}
          type="text"
          placeholder="Age"
          value={Age}
        />
        <input
          onChange={handleGen}
          type="text"
          placeholder="Gender"
          value={Gen}
        />
        <input
          onChange={handleTarCap}
          type="text"
          placeholder="Target Capital"
          value={TarCap}
        />
        <input
          onChange={handleInitCap}
          type="text"
          placeholder="Initial Capital"
          value={InitCap}
        />
        <input
          onChange={handleNoDep}
          type="number"
          placeholder="No of dependents "
          value={NoDep}
        />
        <input
          onChange={handleYrFamInc}
          type="text"
          placeholder="Yearly Family Income"
          value={YrFamInc}
        />
        <input
          onChange={handleMedBill}
          type="text"
          placeholder="Medical Bills"
          value={MedBill}
        />
        <button type="submit">Submit</button>
      </form>
    </div>
  );
}

export default App;
